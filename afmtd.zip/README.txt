AlphaFold is the state of the art method for prediction of 3D structures of proteins
from the amino acid sequence by neural networks. One of the outputs of AlphaFold is
a probability profile of inter-residue distances for all residue pairs. We used this
profile to evaluate any conformation of the studied protein to express its compliance
with the AlphaFold prediction. This value can be used as a collective variable in
metadynamics or parallel tempering metadynamics to accelerate protein folding in
a molecular simulation. We applied this approach on folding of a mini-protein
Trp-cage.

Content:

mtd1 - input and selected output for metadynamics with AlphaFold CV

mtd2 - input and selected output for metadynamics with AlphaFold and
       Alpha-RMSD CVs

ptmtd1 - input and selected output for parallel tempering  metadynamics with
         AlphaFold CV starting from the folded state
ptmtd1/dir-* - inputs for replicas

ptmtd2 - input and selected output for parallel tempering  metadynamics with
         AlphaFold CV starting from the unfolded state
ptmtd2/dir-* - inputs for replicas

ptmtd3 - input and selected output for parallel tempering  metadynamics with
         AlphaFold and Alpha-RMSD CVs starting from the folded state
ptmtd3/dir-* - inputs for replicas

md5sums.txt - MD5 sums of all files

