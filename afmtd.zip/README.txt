AlphaFold is the state of the art method for prediction of 3D structures of proteins
from the amino acid sequence by neural networks. One of the outputs of AlphaFold is
a probability profile of inter-residue distances for all residue pairs. We used this
profile to evaluate any conformation of the studied protein to express its compliance
with the AlphaFold prediction. This value can be used as a collective variable in
metadynamics or parallel tempering metadynamics to accelerate protein folding in
a molecular simulation. We applied this approach on folding of mini-proteins
Trp-cage and beta hairpin.

Content:

trpcage/mtd1 - input and selected output for metadynamics with AlphaFold CV

trpcage/mtd2 - input and selected output for metadynamics with AlphaFold and
       Alpha-RMSD CVs

trpcage/ptmtd1 - input and selected output for parallel tempering  metadynamics
       with AlphaFold CV starting from the folded state
trpcage/ptmtd1/dir-* - inputs for replicas

trpcage/ptmtd2 - input and selected output for parallel tempering  metadynamics
       with AlphaFold CV starting from the unfolded state
trpcage/ptmtd2/dir-* - inputs for replicas

trpcage/ptmtd3 - input and selected output for parallel tempering  metadynamics
       with AlphaFold and Alpha-RMSD CVs starting from the folded state
trpcage/ptmtd3/dir-* - inputs for replicas

trpcage/ptmtd4 - input and selected output for parallel tempering  metadynamics
       with Alpha-RMSD CVs starting from the folded state
trpcage/ptmtd4/dir-* - inputs for replicas

hairpin/mtd1 - input and selected output for metadynamics with AlphaFold CV

hairpin/ptmtd1 - input and selected output for parallel tempering  metadynamics
       with AlphaFold CV starting from the folded state
hairpin/ptmtd1/dir-* - inputs for replicas

md5sums.txt - MD5 sums of all files

