ntomp=1
ntmpi=32

module add mpich3

for i in `seq 0 31`;
do
cp plumed.dat dir-$i/
singularity exec -B $PWD:/scratch --pwd /scratch --nv $img gmx_d grompp -f dir-$i/nvt.mdp -c dir-$i/mtd0.gro -p trpcage.top -o dir-$i/mtd1.tpr -maxwarn 666
rm mdout.mdp
done

mpirun -n $ntmpi --hostfile nodes.txt singularity exec -B $PWD:/scratch --pwd /scratch --nv $img gmx_d mdrun -ntomp $ntomp -deffnm mtd1 -plumed plumed.dat -multidir \
 dir-0 dir-1 dir-2 dir-3 dir-4 dir-5 dir-6 dir-7 dir-8 dir-9 \
 dir-10 dir-11 dir-12 dir-13 dir-14 dir-15 dir-16 dir-17 dir-18 dir-19 \
 dir-20 dir-21 dir-22 dir-23 dir-24 dir-25 dir-26 dir-27 dir-28 dir-29 \
 dir-30 dir-31 -replex 500 -pin on

