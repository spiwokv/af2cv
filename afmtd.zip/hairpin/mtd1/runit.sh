export OMP_NUM_THREADS=12
export GMX_DOUBLE=ON

singularity exec -B \$PWD:/scratch --pwd /scratch --nv /storage/brno12-cerit/home/ljocha/singularity/ljocha-gromacs-2021-3_3.sif gmx_d grompp -f mtd.mdp -c npt1.gro -t npt1.cpt -p hairpin.top -o mtd1.tpr -maxwarn 666
singularity exec -B \$PWD:/scratch --pwd /scratch --nv /storage/brno12-cerit/home/ljocha/singularity/ljocha-gromacs-2021-3_3.sif gmx_d mdrun -ntomp 12 -deffnm mtd1 -plumed plumed.dat

